__title__ = 'quip'
__version__ = '0.1.12'
__author__ = 'Feihong Hsu'
__license__ = 'Apache 2.0'
__copyright__ = 'Copyright 2016 Feihong Hsu'
__all__ = ['WebRunner', 'send']


from .runner import WebRunner, send
